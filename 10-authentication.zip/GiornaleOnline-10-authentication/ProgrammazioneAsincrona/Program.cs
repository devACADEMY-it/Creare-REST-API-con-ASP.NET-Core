﻿using System.Diagnostics;

namespace ProgrammazioneAsincrona
{
    public class Program
    {
        static readonly Stopwatch timer = new Stopwatch();

        // 06-02 FUNZIONI ASINCRONE
        // 1. metodi async
        public static void Main(string[] args)
        {
         
        }

        public async Task FaiQualcosaAsync()
        {
            
        }

        public async Task<int> FaiQualcosaETornaRisultatoAsync()
        {
            return 1;
        }

        // 06-03 ESEMPIO PRATICO
        //// 2 .sync
        //// Blocca il codice
        //public static void Main(string[] args)
        //{
        //    timer.Start();
        //    Console.WriteLine("Inizio programma: " + timer.Elapsed.ToString());

        //    Task1();
        //    Task2();

        //    Console.WriteLine("Fine programma: " + timer.Elapsed.ToString());
        //    timer.Stop();
        //}

        //// 3. async w/await
        //// Non blocca il codice ma aspetta
        //public static async Task Main(string[] args)
        //{
        //    timer.Start();
        //    Console.WriteLine("Inizio programma: " + timer.Elapsed.ToString());

        //    await Task1Async();
        //    await Task2Async();

        //    Console.WriteLine("Fine programma: " + timer.Elapsed.ToString());
        //    timer.Stop();
        //}

        //// 4. async w/await
        //// Non blocca il codice e non aspetta
        //public static async Task Main(string[] args)
        //{
        //    timer.Start();
        //    Console.WriteLine("Inizio programma: " + timer.Elapsed.ToString());

        //    Task task1Task = Task1Async();
        //    Task task2Task = Task2Async();

        //    //await task1Task;
        //    //await task2Task;

        //    // 6.
        //    await Task.WhenAll(task1Task, task2Task);

        //    Console.WriteLine("Fine programma: " + timer.Elapsed.ToString());
        //    timer.Stop();
        //}

        private static void Task1()
        {
            Console.WriteLine("Task 1 Avviato: " + timer.Elapsed.TotalSeconds.ToString());
            Thread.Sleep(2000);
            Console.WriteLine("Task 1 Completato: " + timer.Elapsed.TotalSeconds.ToString());
        }

        private static void Task2()
        {
            Console.WriteLine("Task 2 Avviato: " + timer.Elapsed.TotalSeconds.ToString());
            Thread.Sleep(3000);
            Console.WriteLine("Task 2 Completato: " + timer.Elapsed.TotalSeconds.ToString());
        }

        private static async Task Task1Async()
        {
            Console.WriteLine("Async Task 1 Avviato: " + timer.Elapsed.TotalSeconds.ToString());
            await Task.Delay(2000);
            Console.WriteLine("Async Task 1 Completato: " + timer.Elapsed.TotalSeconds.ToString());
        }

        private static async Task Task2Async()
        {
            Console.WriteLine("Async Task 2 Avviato: " + timer.Elapsed.TotalSeconds.ToString());
            await Task.Delay(3000);
            Console.WriteLine("Async Task 2 Completato: " + timer.Elapsed.TotalSeconds.ToString());
        }

        
    }
}