﻿namespace GiornaleOnline.Models
{
    // 07-02 MODELLI
    public class UtenteModel
    {
        public int Id { get; set; }
        public string? Nome { get; set; }
    }
}
