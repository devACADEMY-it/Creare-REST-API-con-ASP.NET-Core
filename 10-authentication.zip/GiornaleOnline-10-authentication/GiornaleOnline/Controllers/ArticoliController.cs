﻿using GiornaleOnline.DataContext;
using GiornaleOnline.DataContext.Models;
using GiornaleOnline.Extensions;
using GiornaleOnline.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GiornaleOnline.Controllers
{
    [Authorize] // 10-07 PROTEZIONE ROTTE
    [Route("[controller]")]
    [ApiController]
    public class ArticoliController : ControllerBase
    {
        private readonly ILogger<ArticoliController> _logger;

        private readonly GOContext _dc;

        public ArticoliController(ILogger<ArticoliController> logger, GOContext dc)
        {
            _logger = logger;
            _dc = dc;
        }

        [HttpGet]
        [AllowAnonymous] // 10-07 PROTEZIONE ROTTE
        public async Task<ActionResult<IEnumerable<ArticoloModel>>> GetAll()
        {
            return await _dc.Articoli
                .Include(a => a.Categoria)
                .Include(a => a.Autore)
                .Where(x => x.Pubblicato == true)
                .Select(s => s.ToArticoloModel())
                .ToListAsync();
        }

        // 10-10 FUNZIONI PER L'UTENTE LOGGATO
        [HttpGet("miei")]
        public async Task<ActionResult<IEnumerable<ArticoloModel>>> GetMiei()
        {            
            var userIdClaim = this.User.FindFirst("UserId");
            if (userIdClaim == null)
            {
                return BadRequest();
            }
            var userId = Convert.ToInt32(userIdClaim.Value);

            return await _dc.Articoli
                .Include(a => a.Categoria)
                .Include(a => a.Autore)
                .Where(x => x.Autore!.Id == userId)
                .Select(s => s.ToArticoloModel())
                .ToListAsync();
        }

        [HttpGet("{id}")]
        [AllowAnonymous] // 10-07 PROTEZIONE ROTTE
        public async Task<ActionResult<ArticoloModel>> GetById(int id)
        {
            var articolo = await _dc.Articoli
                .Include(a => a.Categoria)
                .Include(a => a.Autore)
                .SingleOrDefaultAsync(x => x.Id == id && x.Pubblicato == true);

            if (articolo == null)
            {
                return NotFound();
            }

            return articolo.ToArticoloModel();
        }


        [HttpGet("edit/{id}")]
        public async Task<ActionResult<ArticoloDTO>> GetDTOById(int id)
        {
            // 10-09 INTERCETTARE L’UTENTE LOGGATO
            var userIdClaim = this.User.FindFirst("UserId");
            if (userIdClaim == null)
            {
                return BadRequest();
            }
            var userId = Convert.ToInt32(userIdClaim.Value);

            var articolo = await _dc.Articoli
                .Include(a => a.Categoria)
                .Include(a => a.Autore)
                .SingleOrDefaultAsync(x => x.Id == id);

            if (articolo == null)
            {
                return NotFound();
            }

            if (articolo.Autore!.Id != userId)
            {
                return Unauthorized();
            }

            var dto = new ArticoloDTO
            {
                Id = articolo.Id,
                Titolo = articolo.Titolo,
                Testo = articolo.Testo,
                //AutoreId = articolo.Autore!.Id, // 10-10 FUNZIONI PER L'UTENTE LOGGATO
                CategoriaId = articolo.Categoria!.Id,
                Pubblicato = articolo.Pubblicato,
                DataCreazione = articolo.DataCreazione,
                DataUltimaModifica = articolo.DataUltimaModifica
            };

            return dto;
        }

        [HttpPost]
        public async Task<ActionResult<ArticoloModel>> Add(ArticoloDTO item)
        {
            // 10-09 INTERCETTARE L’UTENTE LOGGATO
            var userIdClaim = this.User.FindFirst("UserId");
            if (userIdClaim == null)
            {
                return BadRequest();
            }
            var userId = Convert.ToInt32(userIdClaim.Value);

            var categoria = await _dc.Categorie.FindAsync(item.CategoriaId);
            if (categoria == null)
            {
                return Problem("Categoria non trovata", statusCode: StatusCodes.Status400BadRequest);
            }

            //var autore = await _dc.Utenti.FindAsync(item.AutoreId); // 10-10 FUNZIONI PER L'UTENTE LOGGATO
            var autore = await _dc.Utenti.FindAsync(userId);

            if (autore == null)
            {
                return Problem("Autore non trovato.", statusCode: StatusCodes.Status400BadRequest);
            }

            var articolo = new Articolo
            {
                Titolo = item.Titolo,
                Testo = item.Testo,
                Autore = autore,
                Categoria = categoria,
                Pubblicato = item.Pubblicato
            };

            try
            {
                _dc.Articoli.Add(articolo);
                await _dc.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.InnerException?.Message);
                return Problem(ex.InnerException?.Message);
            }

            return CreatedAtAction(
                nameof(Add),
                new { id = articolo.Id },
                articolo.ToArticoloModel());
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<ArticoloModel>> Update(int id, ArticoloDTO item)
        {
            // 10-09 INTERCETTARE L’UTENTE LOGGATO
            var userIdClaim = this.User.FindFirst("UserId");
            if (userIdClaim == null)
            {
                return BadRequest();
            }
            var userId = Convert.ToInt32(userIdClaim.Value);

            if (id != item.Id)
            {
                return BadRequest();
            }

            var articolo = await _dc.Articoli
                .Include(a => a.Autore)
                .SingleOrDefaultAsync(x => x.Id == id);

            if (articolo == null)
            {
                return NotFound();
            }

            if (articolo.Autore!.Id != userId)
            {
                return Unauthorized();
            }

            var categoria = await _dc.Categorie.FindAsync(item.CategoriaId);
            if (categoria == null)
            {
                return BadRequest("Categoria non trovata.");
            }

            articolo.Titolo = item.Titolo;
            articolo.Testo = item.Testo;
            articolo.Categoria = categoria;
            articolo.Pubblicato = item.Pubblicato;
            articolo.DataUltimaModifica = DateTime.Now;

            try
            {
                await _dc.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.InnerException?.Message);
                return Problem(ex.InnerException?.Message);
            }

            return articolo.ToArticoloModel();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            // 10-09 INTERCETTARE L’UTENTE LOGGATO
            var userIdClaim = this.User.FindFirst("UserId");
            if (userIdClaim == null)
            {
                return BadRequest();
            }
            var userId = Convert.ToInt32(userIdClaim.Value);

            var articolo = await _dc.Articoli
                .Include(a => a.Autore)
                .SingleOrDefaultAsync(x => x.Id == id);

            if (articolo == null)
            {
                return NotFound();
            }

            if (articolo.Autore!.Id != userId)
            {
                return Unauthorized();
            }

            _dc.Articoli.Remove(articolo);

            try
            {
                await _dc.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.InnerException?.Message);
                return Problem(ex.InnerException?.Message);
            }

            return NoContent();
        }
    }
}
