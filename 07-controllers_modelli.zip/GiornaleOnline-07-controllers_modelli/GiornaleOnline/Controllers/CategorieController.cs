﻿using GiornaleOnline.DataContext;
using GiornaleOnline.DataContext.Models;
using GiornaleOnline.Extensions;
using GiornaleOnline.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GiornaleOnline.Controllers
{
    // https://docs.microsoft.com/it-it/aspnet/core/web-api/?view=aspnetcore-6.0#apicontroller-attribute
    // https://docs.microsoft.com/it-it/aspnet/core/tutorials/first-web-api?view=aspnetcore-6.0&tabs=visual-studio#routing-and-url-paths
    // 07-01 CONTROLLER
    // 07-03 CATEGORIE CONTROLLER
    [Route("[controller]")]
    [ApiController]
    public class CategorieController : ControllerBase
    {
        private readonly ILogger<CategorieController> _logger;

        private readonly GOContext _dc;

        public CategorieController(ILogger<CategorieController> logger, GOContext dc)
        {
            _logger = logger;
            _dc = dc;
        }

        // 07-04 CATEGORIE GET ALL
        // https://docs.microsoft.com/it-it/aspnet/core/web-api/action-return-types?view=aspnetcore-6.0
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CategoriaModel>>> GetAll()
        {
            var data = await _dc.Categorie.Select(s => s.ToCategoriaModel()).ToListAsync();

            return Ok(data);
        }

        // 07-05 CATEGORIE GET BY ID
        [HttpGet("{id}")]
        public async Task<ActionResult<CategoriaModel>> GetById(int id)
        {
            var categoria = await _dc.Categorie.FindAsync(id);
            // var categoria = _dc.Categorie.SingleOrDefaultAsync(x => x.Id == id);

            if (categoria == null)
            {
                return NotFound();
            }

            return Ok(categoria.ToCategoriaModel());
        }

        // 07-06 CATEGORIE POST
        [HttpGet("edit/{id}")]
        public async Task<ActionResult<CategoriaDTO>> GetDTOById(int id)
        {
            var categoria = await _dc.Categorie.FindAsync(id);

            if (categoria == null)
            {
                return NotFound();
            }

            var dto = new CategoriaDTO
            {                
                Nome = categoria.Nome
            };

            return Ok(dto);
        }

        // 07-06 CATEGORIE POST
        [HttpPost]
        public async Task<ActionResult<CategoriaModel>> Add(CategoriaDTO item)
        {
            var categoria = new Categoria
            {
                Nome = item.Nome
            };

            try
            {
                _dc.Categorie.Add(categoria);
                await _dc.SaveChangesAsync();
            }
            catch (Exception ex)
            {                
                return Problem(ex.Message);
            }

            return CreatedAtAction(
                nameof(Add),
                new { id = categoria.Id },
                categoria.ToCategoriaModel());
        }

        // 07-07 CATEGORIE PUT, DELETE
        [HttpPut("{id}")]
        public async Task<ActionResult<CategoriaModel>> Update(int id, CategoriaDTO item)
        {           
            var categoria = await _dc.Categorie.FindAsync(id);
            if (categoria == null)
            {
                return NotFound();
            }

            categoria.Nome = item.Nome;

            try
            {
                await _dc.SaveChangesAsync();
            }
            catch (Exception ex)
            {                
                return Problem(ex.Message);
            }

            return Ok(categoria.ToCategoriaModel());
        }

        // 07-07 CATEGORIE PUT, DELETE
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var categoria = await _dc.Categorie.FindAsync(id);

            if (categoria == null)
            {
                return NotFound();
            }

            _dc.Categorie.Remove(categoria);

            try
            {
                await _dc.SaveChangesAsync();
            }
            catch (Exception ex)
            {                
                return Problem(ex.Message);
            }

            return NoContent();
        }
    }
}
