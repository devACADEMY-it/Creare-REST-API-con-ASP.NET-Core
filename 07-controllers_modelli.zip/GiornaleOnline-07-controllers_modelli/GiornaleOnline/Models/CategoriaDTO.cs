﻿using System.ComponentModel.DataAnnotations;

namespace GiornaleOnline.Models
{
    // 07-02 MODELLI
    public class CategoriaDTO
    {        

        [Required(ErrorMessage = "Il campo {0} è obbligatorio.")]
        public string? Nome { get; set; }
    }
}
