﻿using GiornaleOnline.DataContext;
using GiornaleOnline.DataContext.Models;
using GiornaleOnline.Extensions;
using GiornaleOnline.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GiornaleOnline.Controllers
{
    // 07-08 ARTICOLI CONTROLLER E MODELLI
    [Route("[controller]")]
    [ApiController]
    public class ArticoliController : ControllerBase
    {
        private readonly ILogger<ArticoliController> _logger;

        private readonly GOContext _dc;

        public ArticoliController(ILogger<ArticoliController> logger, GOContext dc)
        {
            _logger = logger;
            _dc = dc;
        }

        // 07-09 ARTICOLI GET
        // METODO ASINCRONO
        // Il Server ha a disposizione un numero finito di Thread (processi di lavoro/cameriere)
        // Se al server arrivano più richieste contemporaneamente
        // ogni richiesta viene eseguita in parallelo da Thread diversi fino a che ci sono Thread disponibili
        // se non ci sono Thread a disposizione la richiesta viene messa in coda        
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ArticoloModel>>> GetAll()
        {
            return await _dc.Articoli
                .Include(a => a.Categoria)
                .Include(a => a.Autore)
                .Where(x => x.Pubblicato == true)
                .Select(s => s.ToArticoloModel())
                .ToListAsync();
        }

        // 07-09 ARTICOLI GET
        [HttpGet("{id}")]
        public async Task<ActionResult<ArticoloModel>> GetById(int id)
        {
            var articolo = await _dc.Articoli
                .Include(a => a.Categoria)
                .Include(a => a.Autore)
                .SingleOrDefaultAsync(x => x.Id == id && x.Pubblicato == true);

            if (articolo == null)
            {
                return NotFound();
            }           

            return Ok(articolo.ToArticoloModel());
        }

        // 07-10 ARTICOLI POST, PUT, DELETE
        [HttpGet("edit/{id}")]
        public async Task<ActionResult<ArticoloDTO>> GetDTOById(int id)
        {
            var articolo = await _dc.Articoli
                .Include(a => a.Categoria)
                .Include(a => a.Autore)
                .SingleOrDefaultAsync(x => x.Id == id);

            if (articolo == null)
            {
                return NotFound();
            }

            var dto = new ArticoloDTO
            {
                Id = articolo.Id,
                Titolo = articolo.Titolo,
                Testo = articolo.Testo,
                AutoreId= articolo.Autore!.Id,
                CategoriaId = articolo.Categoria!.Id,
                Pubblicato = articolo.Pubblicato,
                DataCreazione = articolo.DataCreazione,
                DataUltimaModifica = articolo.DataUltimaModifica
            };

            return Ok(dto);
        }

        // 07-10 ARTICOLI POST, PUT, DELETE
        [HttpPost]
        public async Task<ActionResult<ArticoloModel>> Add(ArticoloDTO item)
        {
            var categoria = await _dc.Categorie.FindAsync(item.CategoriaId);
            if (categoria == null)
            {
                return Problem("Categoria non trovata", statusCode: StatusCodes.Status400BadRequest);
            }

            var autore = await _dc.Utenti.FindAsync(item.AutoreId);
            if (autore == null)
            {
                return Problem("Autore non trovato.", statusCode: StatusCodes.Status400BadRequest);
            }

            var articolo = new Articolo
            {
                Titolo = item.Titolo,
                Testo = item.Testo,
                Autore = autore,
                Categoria = categoria,
                Pubblicato = item.Pubblicato
            };

            try
            {
                _dc.Articoli.Add(articolo);
                await _dc.SaveChangesAsync();
            }
            catch (Exception ex)
            {                
                return Problem(ex.Message);
            }

            return CreatedAtAction(
                nameof(Add),
                new { id = articolo.Id },
                articolo.ToArticoloModel());
        }

        // 07-10 ARTICOLI POST, PUT, DELETE
        [HttpPut("{id}")]
        public async Task<ActionResult<ArticoloModel>> Update(int id, ArticoloDTO item)
        {
            if (id != item.Id)
            {
                return BadRequest();
            }

            var articolo = await _dc.Articoli.FindAsync(id);
            if (articolo == null)
            {
                return NotFound();
            }

            var categoria = await _dc.Categorie.FindAsync(item.CategoriaId);
            if (categoria == null)
            {
                return BadRequest("Categoria non trovata.");
            }

            var autore = await _dc.Utenti.FindAsync(item.AutoreId);
            if (autore == null)
            {
                return BadRequest("Autore non trovato.");
            }

            articolo.Titolo = item.Titolo;
            articolo.Testo = item.Testo;
            articolo.Autore = autore;
            articolo.Categoria = categoria;
            articolo.Pubblicato = item.Pubblicato;
            articolo.DataUltimaModifica = DateTime.Now;

            try
            {
                await _dc.SaveChangesAsync();
            }
            catch (Exception ex)
            {                
                return Problem(ex.Message);
            }

            return Ok(articolo.ToArticoloModel());
        }

        // 07-10 ARTICOLI POST, PUT, DELETE
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var articolo = await _dc.Articoli.FindAsync(id);

            if (articolo == null)
            {
                return NotFound();
            }

            _dc.Articoli.Remove(articolo);

            try
            {
                await _dc.SaveChangesAsync();
            }
            catch (Exception ex)
            {                
                return Problem(ex.Message);
            }

            return NoContent();
        }
    }
}
