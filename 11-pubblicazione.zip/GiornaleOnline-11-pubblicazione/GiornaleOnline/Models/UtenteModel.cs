﻿namespace GiornaleOnline.Models
{
    public class UtenteModel
    {
        public int Id { get; set; }
        public string? Nome { get; set; }

        // 10-03 GESTIONE UTENTI DATABASE
        public string? Username { get; set; }
    }
}
