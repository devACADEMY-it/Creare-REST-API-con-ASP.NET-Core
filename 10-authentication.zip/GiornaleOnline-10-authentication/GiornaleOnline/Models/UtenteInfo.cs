﻿using GiornaleOnline.DataContext.Models;

namespace GiornaleOnline.Models
{
    // 10-04 UTENTI CONTROLLER E MODELS
    public class UtenteInfo
    {
        public UtenteModel? Utente { get; set; }

        public string? Token { get; set; }
    }
}
