﻿namespace GiornaleOnline.Models
{
    // 07-02 MODELLI
    public class CategoriaModel
    {
        public int Id { get; set; }
        public string? Nome { get; set; }
    }
}
